function checkForName(inputText) {
    console.log("::: Running checkForName :::", inputText);
    const captains  = [
        "Picard",
        "Janeway",
        "Kirk",
        "Archer",
        "Georgiou"
    ]
    const isCaptain = captains.some(captain => captain === inputText.trim());

    if(names.includes(inputText)) {
        alert("Welcome, Captain!")
    }
}

export { checkForName }
